package ph.arena.app

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.ScreenCapturerAndroid
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoSource
import org.webrtc.VideoTrack

/**
 * Native screen capture + WebRTC sender. The web app (index.html) keeps doing all signaling
 * (Supabase Realtime); this engine only creates the offers/answers/ICE for the media.
 */
object LiveEngine {
    interface Listener {
        fun onOffer(viewer: String, type: String, sdp: String)
        fun onIce(viewer: String, json: String)
        fun onConn(viewer: String, state: String)
        fun onStopped()
    }

    @Volatile var projectionData: Intent? = null
    var onServiceReady: (() -> Unit)? = null
    var listener: Listener? = null

    private val main = Handler(Looper.getMainLooper())
    private var factory: PeerConnectionFactory? = null
    private var egl: EglBase? = null
    private var capturer: ScreenCapturerAndroid? = null
    private var helper: SurfaceTextureHelper? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var audioSource: AudioSource? = null
    private var audioTrack: AudioTrack? = null
    private val peers = HashMap<String, PeerConnection>()
    private var running = false
    private var iceServers: List<PeerConnection.IceServer> = listOf(
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
    )

    private open class Obs : PeerConnection.Observer {
        override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
        override fun onIceConnectionChange(p0: PeerConnection.IceConnectionState?) {}
        override fun onIceConnectionReceivingChange(p0: Boolean) {}
        override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
        override fun onIceCandidate(p0: IceCandidate?) {}
        override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
        override fun onAddStream(p0: MediaStream?) {}
        override fun onRemoveStream(p0: MediaStream?) {}
        override fun onDataChannel(p0: DataChannel?) {}
        override fun onRenegotiationNeeded() {}
    }

    private open class Sdp : SdpObserver {
        override fun onCreateSuccess(p0: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(p0: String?) {}
        override fun onSetFailure(p0: String?) {}
    }

    private fun init(ctx: Context) {
        if (factory != null) return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(ctx.applicationContext).createInitializationOptions()
        )
        val e = EglBase.create()
        egl = e
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(e.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(e.eglBaseContext))
            .createPeerConnectionFactory()
    }

    fun setIce(json: String) {
        try {
            val a = JSONArray(json)
            val list = ArrayList<PeerConnection.IceServer>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val urls = ArrayList<String>()
                val u = o.opt("urls")
                if (u is JSONArray) {
                    for (j in 0 until u.length()) urls.add(u.getString(j))
                } else if (u != null) {
                    urls.add(u.toString())
                }
                if (urls.isEmpty()) continue
                val b = PeerConnection.IceServer.builder(urls)
                if (o.has("username")) b.setUsername(o.getString("username"))
                if (o.has("credential")) b.setPassword(o.getString("credential"))
                list.add(b.createIceServer())
            }
            if (list.isNotEmpty()) iceServers = list
        } catch (e: Exception) {
        }
    }

    /** Called on the main thread after the foreground service is running. Returns an error text or null. */
    @Suppress("DEPRECATION")
    fun start(ctx: Context, mic: Boolean): String? {
        val data = projectionData ?: return "Screen permission missing"
        return try {
            init(ctx)
            val f = factory!!
            val dm = DisplayMetrics()
            (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
            var w = dm.widthPixels
            var h = dm.heightPixels
            val scale = minOf(1.0, 1280.0 / maxOf(w, h).toDouble())
            w = ((w * scale).toInt() / 2) * 2
            h = ((h * scale).toInt() / 2) * 2

            val cap = ScreenCapturerAndroid(data, object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post {
                        if (running) {
                            stopInternal()
                            listener?.onStopped()
                        }
                    }
                }
            })
            capturer = cap
            val th = SurfaceTextureHelper.create("ArenaScreen", egl!!.eglBaseContext)
            helper = th
            val vs = f.createVideoSource(true)
            videoSource = vs
            cap.initialize(th, ctx.applicationContext, vs.capturerObserver)
            cap.startCapture(w, h, 24)
            videoTrack = f.createVideoTrack("screen0", vs)
            if (mic) {
                val asrc = f.createAudioSource(MediaConstraints())
                audioSource = asrc
                audioTrack = f.createAudioTrack("mic0", asrc)
            }
            running = true
            null
        } catch (e: Exception) {
            stopInternal()
            e.message ?: e.javaClass.simpleName
        }
    }

    fun offer(viewer: String) {
        main.post {
            val f = factory
            val vt = videoTrack
            if (!running || f == null || vt == null) return@post
            drop(viewer)
            val cfg = PeerConnection.RTCConfiguration(iceServers)
            cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            val pc = f.createPeerConnection(cfg, object : Obs() {
                override fun onIceCandidate(p0: IceCandidate?) {
                    val c = p0 ?: return
                    val o = JSONObject()
                    o.put("candidate", c.sdp)
                    o.put("sdpMid", c.sdpMid)
                    o.put("sdpMLineIndex", c.sdpMLineIndex)
                    main.post { listener?.onIce(viewer, o.toString()) }
                }

                override fun onConnectionChange(p0: PeerConnection.PeerConnectionState?) {
                    val s = when (p0) {
                        PeerConnection.PeerConnectionState.CONNECTED -> "connected"
                        PeerConnection.PeerConnectionState.FAILED -> "failed"
                        PeerConnection.PeerConnectionState.DISCONNECTED -> "disconnected"
                        PeerConnection.PeerConnectionState.CLOSED -> "closed"
                        else -> return
                    }
                    main.post { listener?.onConn(viewer, s) }
                }
            }) ?: return@post
            peers[viewer] = pc
            pc.addTrack(vt, listOf("ap"))
            audioTrack?.let { pc.addTrack(it, listOf("ap")) }
            pc.createOffer(object : Sdp() {
                override fun onCreateSuccess(p0: SessionDescription?) {
                    val d = p0 ?: return
                    pc.setLocalDescription(object : Sdp() {
                        override fun onSetSuccess() {
                            val ld = pc.localDescription ?: return
                            main.post {
                                listener?.onOffer(viewer, "offer", ld.description)
                                limitBitrate(pc)
                            }
                        }
                    }, d)
                }
            }, MediaConstraints())
        }
    }

    private fun limitBitrate(pc: PeerConnection) {
        try {
            for (s in pc.senders) {
                if (s.track()?.kind() == "video") {
                    val p = s.parameters
                    for (e in p.encodings) {
                        e.maxBitrateBps = 1_500_000
                        e.maxFramerate = 24
                    }
                    s.setParameters(p)
                }
            }
        } catch (e: Exception) {
        }
    }

    fun answer(viewer: String, sdp: String) {
        main.post {
            val pc = peers[viewer] ?: return@post
            pc.setRemoteDescription(Sdp(), SessionDescription(SessionDescription.Type.ANSWER, sdp))
        }
    }

    fun ice(viewer: String, json: String) {
        main.post {
            val pc = peers[viewer] ?: return@post
            try {
                val o = JSONObject(json)
                val mid = if (o.isNull("sdpMid")) "0" else o.getString("sdpMid")
                pc.addIceCandidate(IceCandidate(mid, o.optInt("sdpMLineIndex", 0), o.getString("candidate")))
            } catch (e: Exception) {
            }
        }
    }

    fun drop(viewer: String) {
        main.post {
            peers.remove(viewer)?.let {
                try {
                    it.close()
                    it.dispose()
                } catch (e: Exception) {
                }
            }
        }
    }

    fun setMic(on: Boolean) {
        main.post { audioTrack?.setEnabled(on) }
    }

    fun stop() {
        main.post { stopInternal() }
    }

    private fun stopInternal() {
        running = false
        for (pc in peers.values) {
            try {
                pc.close()
                pc.dispose()
            } catch (e: Exception) {
            }
        }
        peers.clear()
        try { capturer?.stopCapture() } catch (e: Exception) {}
        try { capturer?.dispose() } catch (e: Exception) {}
        try { helper?.dispose() } catch (e: Exception) {}
        try { videoTrack?.dispose() } catch (e: Exception) {}
        try { videoSource?.dispose() } catch (e: Exception) {}
        try { audioTrack?.dispose() } catch (e: Exception) {}
        try { audioSource?.dispose() } catch (e: Exception) {}
        capturer = null
        helper = null
        videoTrack = null
        videoSource = null
        audioTrack = null
        audioSource = null
        projectionData = null
    }
}
