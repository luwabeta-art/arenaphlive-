package ph.arena.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var prefs: SharedPreferences
    private var webReq: PermissionRequest? = null
    private var wantMic = true
    private var host: String? = null

    private val permWeb = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val r = webReq
        webReq = null
        if (r != null) {
            val ok = r.resources.filter {
                when (it) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> has(Manifest.permission.CAMERA)
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> has(Manifest.permission.RECORD_AUDIO)
                    else -> false
                }
            }.toTypedArray()
            if (ok.isEmpty()) r.deny() else r.grant(ok)
        }
    }

    private val permScreen = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        wantMic = wantMic && has(Manifest.permission.RECORD_AUDIO)
        askProjection()
    }

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            LiveEngine.projectionData = data
            LiveEngine.onServiceReady = {
                val err = LiveEngine.start(this, wantMic)
                if (err == null) {
                    js("window.__nScreen&&window.__nScreen(true,'')")
                } else {
                    stopService(Intent(this, ScreenService::class.java))
                    js("window.__nScreen&&window.__nScreen(false," + JSONObject.quote(err) + ")")
                }
            }
            val svc = Intent(this, ScreenService::class.java).putExtra("mic", wantMic)
            try {
                ContextCompat.startForegroundService(this, svc)
            } catch (e: Exception) {
                LiveEngine.onServiceReady = null
                js("window.__nScreen&&window.__nScreen(false," + JSONObject.quote(e.message ?: "Could not start") + ")")
            }
        } else {
            js("window.__nScreen&&window.__nScreen(false,'Screen sharing was not allowed')")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        prefs = getSharedPreferences("arena", Context.MODE_PRIVATE)
        web = WebView(this)
        setContentView(web)
        setupWeb()

        LiveEngine.listener = object : LiveEngine.Listener {
            override fun onOffer(viewer: String, type: String, sdp: String) =
                js("window.__nOffer&&window.__nOffer(${JSONObject.quote(viewer)},${JSONObject.quote(type)},${JSONObject.quote(sdp)})")

            override fun onIce(viewer: String, json: String) =
                js("window.__nIce&&window.__nIce(${JSONObject.quote(viewer)},${JSONObject.quote(json)})")

            override fun onConn(viewer: String, state: String) =
                js("window.__nConn&&window.__nConn(${JSONObject.quote(viewer)},${JSONObject.quote(state)})")

            override fun onStopped() {
                runOnUiThread { stopService(Intent(this@MainActivity, ScreenService::class.java)) }
                js("window.__nStop&&window.__nStop()")
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else moveTaskToBack(true)
            }
        })

        val url = prefs.getString("url", null)
        if (url.isNullOrEmpty()) askUrl() else load(url)
    }

    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    private fun load(url: String) {
        host = Uri.parse(url).host
        web.loadUrl(url)
    }

    private fun askUrl() {
        val et = EditText(this)
        et.hint = "https://your-arenaph-link"
        et.setText(prefs.getString("url", "https://"))
        et.setSelection(et.text.length)
        AlertDialog.Builder(this)
            .setTitle("Your ArenaPH link")
            .setMessage("Paste the https link where you host ArenaPH (for example https://yourname.pages.dev).")
            .setView(et)
            .setCancelable(prefs.getString("url", null) != null)
            .setPositiveButton("Open") { _, _ ->
                var u = et.text.toString().trim()
                if (u.isNotEmpty()) {
                    if (!u.startsWith("http")) u = "https://$u"
                    if (!u.startsWith("https://")) u = "https://" + u.removePrefix("http://")
                    prefs.edit().putString("url", u).apply()
                    load(u)
                } else {
                    askUrl()
                }
            }
            .show()
    }

    private fun loadError() {
        AlertDialog.Builder(this)
            .setTitle("Could not load ArenaPH")
            .setMessage("Check your internet connection and your link.")
            .setPositiveButton("Retry") { _, _ -> web.reload() }
            .setNegativeButton("Change link") { _, _ -> askUrl() }
            .show()
    }

    private fun external(u: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, u))
        } catch (e: Exception) {
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb() {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.userAgentString = s.userAgentString + " ArenaPHApp/1"
        web.setBackgroundColor(Color.parseColor("#0B0D14"))
        if (Build.VERSION.SDK_INT >= 26) web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
        if ((applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true)
        CookieManager.getInstance().setAcceptCookie(true)
        web.addJavascriptInterface(Bridge(), "AndroidLive")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false
                val u = request.url
                val h = u.host
                if ((u.scheme == "https" || u.scheme == "http") && h != null && h == host) return false
                external(u)
                return true
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) loadError()
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val need = ArrayList<String>()
                    for (r in request.resources) {
                        if (r == PermissionRequest.RESOURCE_VIDEO_CAPTURE && !has(Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA)
                        if (r == PermissionRequest.RESOURCE_AUDIO_CAPTURE && !has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO)
                    }
                    if (need.isEmpty()) {
                        request.grant(request.resources)
                    } else {
                        webReq = request
                        permWeb.launch(need.toTypedArray())
                    }
                }
            }
        }
    }

    private fun askProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projLauncher.launch(mpm.createScreenCaptureIntent())
    }

    inner class Bridge {
        @JavascriptInterface fun isNative(): Boolean = true

        @JavascriptInterface fun startScreen(mic: Boolean) {
            runOnUiThread {
                wantMic = mic
                val need = ArrayList<String>()
                if (mic && !has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO)
                if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS)
                if (need.isEmpty()) askProjection() else permScreen.launch(need.toTypedArray())
            }
        }

        @JavascriptInterface fun setIce(json: String) = LiveEngine.setIce(json)
        @JavascriptInterface fun offer(viewer: String) = LiveEngine.offer(viewer)
        @JavascriptInterface fun answer(viewer: String, type: String, sdp: String) = LiveEngine.answer(viewer, sdp)
        @JavascriptInterface fun ice(viewer: String, json: String) = LiveEngine.ice(viewer, json)
        @JavascriptInterface fun drop(viewer: String) = LiveEngine.drop(viewer)
        @JavascriptInterface fun setMic(on: Boolean) = LiveEngine.setMic(on)

        @JavascriptInterface fun stopScreen() {
            LiveEngine.stop()
            runOnUiThread { stopService(Intent(this@MainActivity, ScreenService::class.java)) }
        }

        @JavascriptInterface fun changeLink() {
            runOnUiThread { askUrl() }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) {
            LiveEngine.stop()
            stopService(Intent(this, ScreenService::class.java))
        }
    }
}
