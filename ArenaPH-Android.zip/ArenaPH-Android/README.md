# ArenaPH Android (screen live inside ArenaPH)

This app opens your hosted ArenaPH site in a WebView and adds what Android browsers cannot do:
**capture the phone screen and send it live**. Chat, gifts, viewers, tournaments and the live room all stay
the ArenaPH web app. Only the screen video is sent by native code.

## 1. Host the updated index.html
Upload the new `index.html` (it contains the Android bridge) to your https host (Cloudflare Pages, Netlify...).
The Android app loads that link, so every time you update the file there, the app updates too.

## 2. Build the APK (pick one)

**A) Android Studio (computer)**
1. Install Android Studio. File > Open > select this folder.
2. Wait for the Gradle sync to finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Copy `app/build/outputs/apk/debug/app-debug.apk` to your phone and install it (allow "install unknown apps").

**B) GitHub (no Android Studio)**
1. Create a free GitHub repository and upload ALL files of this folder, keeping the folders
   (`.github`, `app`, `gradle` and the files in the root). Use a computer or "Desktop site" in the phone browser.
2. Open the Actions tab > "Build APK" > Run workflow (it also runs on every upload).
3. When it finishes (about 5 minutes), open the run and download the artifact `ArenaPH-APK`.
   Unzip it and install `app-debug.apk` on your phone.

## 3. First launch
Paste your https ArenaPH link when asked. To change it later: if the page fails to load, tap "Change link".

## 4. Go live with the screen
Open a tournament you host > Go Live > "Stream my phone screen" > Start now.
Keep your game open: a notification "ArenaPH Live" shows while your screen is shared. Tap it to return.
Stop with the notification or by ending the stream in ArenaPH.

## Known limits (honest)
- Viewers hear your **microphone** (so game sound through the speaker is picked up, but internal game audio is not captured).
- The capture size follows the phone orientation when you press Start. Rotate first, then start.
- A native host serves 3 viewers directly; viewers relay to each other, so roughly 39 viewers total.
- For very large audiences also stream to YouTube/Facebook and paste the link.
- If you use the Agora engine, screen lives made in this app always use the direct/relay path.
